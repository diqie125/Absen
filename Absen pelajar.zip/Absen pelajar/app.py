from flask import Flask, render_template, request, redirect, url_for, session
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'secret123'

# Simulasi database (pakai dictionary)
users = {}
absensi_data = []

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form['username']
        pw = request.form['password']
        if user in users and users[user] == pw:
            session['username'] = user
            return redirect(url_for('home'))
        else:
            return "Login gagal!"
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        user = request.form['username']
        pw = request.form['password']
        if user in users:
            return "Username sudah terdaftar!"
        users[user] = pw
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/home', methods=['GET', 'POST'])
def home():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        waktu = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        absensi_data.append({'nama': session['username'], 'waktu': waktu})

    return render_template('home.html', nama=session['username'], absen=absensi_data)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run()